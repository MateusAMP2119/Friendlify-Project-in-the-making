let now_playing = document.querySelector('.now-playing');
let track_art = document.querySelector('.track-art');
let track_name = document.querySelector('.track-name');
let track_artist = document.querySelector('.track-artist');

let playpause_btn = document.querySelector('.playpause-track');
let next_btn = document.querySelector('.next-track');
let prev_btn = document.querySelector('.prev-track');

let seek_slider = document.querySelector('.seek_slider');
let volume_slider = document.querySelector('.volume_slider');
let curr_time = document.querySelector('.current-time');
let total_duration = document.querySelector('.total-duration');
let wave = document.getElementById('wave');
let randomIcon = document.querySelector('.fa-random');
let curr_track = document.createElement('audio');

let track_index = 0;
let isPlaying = false;
let isRandom = false;
let updateTimer;

//chat

const possibleEmojis = 
[
    '🐀','🐁','🐭','🐹','🐂','🐃','🐄','🐮','🐅','🐆','🐯','🐇','🐐','🐑','🐏','🐴',
    '🐎','🐱','🐈','🐰','🐓','🐔','🐤','🐣','🐥','🐦','🐧','🐘','🐩','🐕','🐷','🐖',
    '🐗','🐫','🐪','🐶','🐺','🐻','🐨','🐼','🐵','🙈','🙉','🙊','🐒','🐉','🐲','🐊',
    '🐍','🐢','🐸','🐋','🐳','🐬','🐙','🐟','🐠','🐡','🐚','🐌','🐛','🐜','🐝','🐞',
];

function randomEmoji() 
{
    var randomIndex = Math.floor(Math.random() * possibleEmojis.length);
    return possibleEmojis[randomIndex];
}

const emoji = randomEmoji();
//const name = prompt("What's your name?");

// Generate random room name
if (!location.hash) 
{
    location.hash = Math.floor(Math.random() * 0xFFFFFF).toString(16);
}
const Hash = location.hash.substring(1);

//channel ID
const drone = new ScaleDrone('yiS12Ts5RdNhebyM');

// Scaledrone room name needs to be prefixed with 'observable-'
const roomName = 'observable-' + Hash;

let room;

const configuration = 
{
    iceServers: 
    [{
      url: 'stun:stun.l.google.com:19302'
    }]
};
// RTCPeerConnection
let pc;
// RTCDataChannel
let dataChannel;

drone.on('open', error => 
{
    if (error) 
    {
      return console.error(error);
    }
    room = drone.subscribe(roomName);
    room.on('open', error => 
    {
      if (error) 
      {
        return console.error(error);
      }
      console.log('Connected to signaling server');
    });
    // We're connected to the room and received an array of 'members'
    // connected to the room (including us). Signaling server is ready.
    room.on('members', members => 
    {
      if (members.length >= 3) 
      {
        return alert('The room is full');
      }
      // If we are the second user to connect to the room we will be creating the offer
      const isOfferer = members.length === 2;
      startWebRTC(isOfferer);
    });

});

// Send signaling data via Scaledrone
function sendMessage(message) 
{
    drone.publish
    ({
      room: roomName,
      message
    });
}

function startWebRTC(isOfferer) 
{
    console.log('Starting WebRTC in as', isOfferer ? 'offerer' : 'waiter');
    pc = new RTCPeerConnection(configuration);
  
    // 'onicecandidate' notifies us whenever an ICE agent needs to deliver a
    // message to the other peer through the signaling server

    pc.onicecandidate = event => 
    {
      if (event.candidate) 
      {
        sendMessage({'candidate': event.candidate});
      }
    };

    if (isOfferer) 
    {
        // If user is offerer let them create a negotiation offer and set up the data channel
        pc.onnegotiationneeded = () => 
        {
          pc.createOffer(localDescCreated, error => console.error(error));
        }
        dataChannel = pc.createDataChannel('chat');
        setupDataChannel();
    } 
    else 
    {

        // If user is not the offerer let wait for a data channel
        pc.ondatachannel = event => 
        {
          dataChannel = event.channel;
          setupDataChannel();
        }
    }

    pc.ontrack = event => 
    {
      const stream = event.streams[0];
      if (!remoteVideo.srcObject || remoteVideo.srcObject.id !== stream.id) 
      {
        remoteVideo.srcObject = stream;
      }
    };
  
    navigator.mediaDevices.getUserMedia
    ({
      audio: true,
      video: true,
    }).then(stream => 
    {
      // Display your local video in #localVideo element
      localVideo.srcObject = stream;
      // Add your stream to be sent to the conneting peer
      stream.getTracks().forEach(track => pc.addTrack(track, stream));
    }, onError);
  
    // Listen to signaling data from Scaledrone
    room.on('data', (message, client) => 
    {
        // Message was sent by us
        if (client.id === drone.clientId) 
        {
            return;
        }
  
        if (message.sdp) 
        {
            // This is called after receiving an offer or answer from another peer
            pc.setRemoteDescription(new RTCSessionDescription(message.sdp), () => 
            {
                // When receiving an offer lets answer it
                if (pc.remoteDescription.type === 'offer') 
                {
                    pc.createAnswer().then(localDescCreated).catch(onError);
                }

            }, onError);
        } else if (message.candidate) 
        { 
            // Add the new ICE candidate to our connections remote description
            pc.addIceCandidate
            (
                new RTCIceCandidate(message.candidate), onSuccess, onError
            );

        }
    });
    
    startListentingToSignals();
}

function startListentingToSignals() 
{
    // Listen to signaling data from Scaledrone
    room.on('data', (message, client) => 
    {
      // Message was sent by us
      if (client.id === drone.clientId) 
      {
        return;
      }
      if (message.sdp) 
      {
        // This is called after receiving an offer or answer from another peer
        pc.setRemoteDescription(new RTCSessionDescription(message.sdp), () => 
        {
          console.log('pc.remoteDescription.type', pc.remoteDescription.type);
          // When receiving an offer lets answer it
          if (pc.remoteDescription.type === 'offer') 
          {
            console.log('Answering offer');
            pc.createAnswer(localDescCreated, error => console.error(error));
          }
        }, error => console.error(error));
      } else if (message.candidate)
      {
        // Add the new ICE candidate to our connections remote description
        pc.addIceCandidate(new RTCIceCandidate(message.candidate));
      }
    });
}

function localDescCreated(desc) 
{
    pc.setLocalDescription
    (
      desc,
      () => sendMessage({'sdp': pc.localDescription}),
      error => console.error(error)
    );
}

function setupDataChannel() 
{
    checkDataChannelState();
    dataChannel.onopen = checkDataChannelState;
    dataChannel.onclose = checkDataChannelState;
    dataChannel.onmessage = event =>
    insertMessageToDOM(JSON.parse(event.data), false)
}

function checkDataChannelState() 
{
    console.log('WebRTC channel state is:', dataChannel.readyState);
    if (dataChannel.readyState === 'open') {
      insertMessageToDOM({content: 'WebRTC data channel is now open'});
    }
}

function insertMessageToDOM(options, isFromMe) 
{
    const template = document.querySelector('template[data-template="message"]');
    const nameEl = template.content.querySelector('.message__name');
    if (options.emoji || options.name) 
    {
      nameEl.innerText = options.emoji + ' ' + options.name;
    }
    template.content.querySelector('.message__bubble').innerText = options.content;
    const clone = document.importNode(template.content, true);
    const messageEl = clone.querySelector('.message');
    if (isFromMe) 
    {
      messageEl.classList.add('message--mine');
    } else 
    {
      messageEl.classList.add('message--theirs');
    }
  
    const messagesEl = document.querySelector('.messages');
    messagesEl.appendChild(clone);
  
    // Scroll to bottom
    messagesEl.scrollTop = messagesEl.scrollHeight - messagesEl.clientHeight;
}

const form = document.querySelector('form');
form.addEventListener('submit', () => 
{
  const input = document.querySelector('input[type="text"]');
  const value = input.value;
  input.value = '';
 
  const data = 
  {
    name,
    content: value,
    emoji,
  };
 
  dataChannel.send(JSON.stringify(data));
 
  insertMessageToDOM(data, true);
});
 
//insertMessageToDOM({content: 'Chat URL is ' + location.href});

//video
  
  
function onSuccess() {};
function onError(error) 
{
    console.error(error);
};
  
drone.on('open', error => 
{
    if (error) 
    {
      return console.error(error);
    }
    room = drone.subscribe(roomName);
    room.on('open', error => 
    {
        if (error) 
        {
            onError(error);
        }
    });

    // We're connected to the room and received an array of 'members'
    // connected to the room (including us). Signaling server is ready.

    room.on('members', members => 
    {
        console.log('MEMBERS', members);
        // If we are the second user to connect to the room we will be creating the offer
        const isOfferer = members.length === 2;
        startWebRTC(isOfferer);
    });

});


//music
const music_list = 
[

    {
        img : 'images/stay.png',
        name : 'Stay',
        artist : 'The Kid LAROI, Justin Bieber',
        music : 'music/stay.mp3'
    },
    {
        img : 'images/fallingdown.jpg',
        name : 'Falling Down',
        artist : 'Wid Cards',
        music : 'music/fallingdown.mp3'
    },
    {
        img : 'images/faded.png',
        name : 'Faded',
        artist : 'Alan Walker',
        music : 'music/Faded.mp3'
    },
    {
        img : 'images/ratherbe.jpg',
        name : 'Rather Be',
        artist : 'Clean Bandit',
        music : 'music/Rather Be.mp3'
    }
];

loadTrack(track_index);

function loadTrack(track_index){
    clearInterval(updateTimer);
    reset();

    curr_track.src = music_list[track_index].music;
    curr_track.load();

    track_art.style.backgroundImage = "url(" + music_list[track_index].img + ")";
    track_name.textContent = music_list[track_index].name;
    track_artist.textContent = music_list[track_index].artist;
    now_playing.textContent = "Playing music " + (track_index + 1) + " of " + music_list.length;

    updateTimer = setInterval(setUpdate, 1000);

    curr_track.addEventListener('ended', nextTrack);
    random_bg_color();
}

function random_bg_color(){
    let hex = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e'];
    let a;

    function populate(a){
        for(let i=0; i<6; i++){
            let x = Math.round(Math.random() * 14);
            let y = hex[x];
            a += y;
        }
        return a;
    }
    let Color1 = populate('#');
    let Color2 = populate('#');
    var angle = 'to right';

    let gradient = 'linear-gradient(' + angle + ',' + Color1 + ', ' + Color2 + ")";
    document.body.style.background = gradient;
}
function reset(){
    curr_time.textContent = "00:00";
    total_duration.textContent = "00:00";
    seek_slider.value = 0;
}
function randomTrack(){
    isRandom ? pauseRandom() : playRandom();
}
function playRandom(){
    isRandom = true;
    randomIcon.classList.add('randomActive');
}
function pauseRandom(){
    isRandom = false;
    randomIcon.classList.remove('randomActive');
}
function repeatTrack(){
    let current_index = track_index;
    loadTrack(current_index);
    playTrack();
}
function playpauseTrack(){
    isPlaying ? pauseTrack() : playTrack();
}
function playTrack(){
    curr_track.play();
    isPlaying = true;
    track_art.classList.add('rotate');
    wave.classList.add('loader');
    playpause_btn.innerHTML = '<i class="fa fa-pause-circle fa-5x"></i>';
}
function pauseTrack(){
    curr_track.pause();
    isPlaying = false;
    track_art.classList.remove('rotate');
    wave.classList.remove('loader');
    playpause_btn.innerHTML = '<i class="fa fa-play-circle fa-5x"></i>';
}
function nextTrack(){
    if(track_index < music_list.length - 1 && isRandom === false){
        track_index += 1;
    }else if(track_index < music_list.length - 1 && isRandom === true){
        let random_index = Number.parseInt(Math.random() * music_list.length);
        track_index = random_index;
    }else{
        track_index = 0;
    }
    loadTrack(track_index);
    playTrack();
}
function prevTrack(){
    if(track_index > 0){
        track_index -= 1;
    }else{
        track_index = music_list.length -1;
    }
    loadTrack(track_index);
    playTrack();
}
function seekTo(){
    let seekto = curr_track.duration * (seek_slider.value / 100);
    curr_track.currentTime = seekto;
}
function setVolume(){
    curr_track.volume = volume_slider.value / 100;
}
function setUpdate()
{
    let seekPosition = 0;
    if(!isNaN(curr_track.duration)){
        seekPosition = curr_track.currentTime * (100 / curr_track.duration);
        seek_slider.value = seekPosition;

        let currentMinutes = Math.floor(curr_track.currentTime / 60);
        let currentSeconds = Math.floor(curr_track.currentTime - currentMinutes * 60);
        let durationMinutes = Math.floor(curr_track.duration / 60);
        let durationSeconds = Math.floor(curr_track.duration - durationMinutes * 60);

        if(currentSeconds < 10) {currentSeconds = "0" + currentSeconds; }
        if(durationSeconds < 10) { durationSeconds = "0" + durationSeconds; }
        if(currentMinutes < 10) {currentMinutes = "0" + currentMinutes; }
        if(durationMinutes < 10) { durationMinutes = "0" + durationMinutes; }

        curr_time.textContent = currentMinutes + ":" + currentSeconds;
        total_duration.textContent = durationMinutes + ":" + durationMinutes;
    }
}

function linkCopy()
{

  navigator.clipboard.writeText("http://127.0.0.1:5500/#"+Hash);
  alert('Room link copyed to clipboard')

}